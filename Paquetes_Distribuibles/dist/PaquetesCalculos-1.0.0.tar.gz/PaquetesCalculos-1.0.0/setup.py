from setuptools import setup

setup(
    name="PaquetesCalculos",
    version="1.0.0",
    description="Paquete de redondeo y potencia",
    author="Brian",
    packages=["Calculos","Calculos"]
)