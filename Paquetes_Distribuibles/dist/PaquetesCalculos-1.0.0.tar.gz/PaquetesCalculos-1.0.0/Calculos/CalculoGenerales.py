#Paquete calculo generales

def sumar(op1, op2):
    print("El resulrado de la suma es: ", op1+op2)

def restar(op1, op2):
    print("El resulrado de la resta es: ", op1-op2)

def multiplicar(op1, op2):
    print("El resulrado de la multipliacion es: ", op1*op2)

def dividir(dividendo, divisor):
    print("El resulrado de la division es: ", dividendo/divisor)

def potencia(base, exponente):
    print("El resulrado de la suma es: ", base**exponente)

def redondear(numero):
    print("El resulrado es: ", round(numero))